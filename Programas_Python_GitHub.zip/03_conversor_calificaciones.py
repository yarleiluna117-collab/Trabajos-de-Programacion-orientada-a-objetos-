# 3. Conversor de calificaciones

calificacion = float(input("Ingresa una calificación de 0 a 100: "))

if calificacion < 0 or calificacion > 100:
    print("Calificación no válida.")
elif calificacion >= 90:
    print("Equivalencia: A")
elif calificacion >= 80:
    print("Equivalencia: B")
elif calificacion >= 70:
    print("Equivalencia: C")
elif calificacion >= 60:
    print("Equivalencia: D")
else:
    print("Equivalencia: F")
