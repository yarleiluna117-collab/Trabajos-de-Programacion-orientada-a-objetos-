# Simulador Pokémon

Proyecto de consola en Python para practicar programación orientada a objetos.

## Estructura
- `main.py`: menú e interacción con el usuario.
- `clases/pokemon.py`: clase Pokemon.
- `clases/__init__.py`: permite importar el paquete.

## Requisitos
Python 3.10 o posterior recomendado. No requiere instalar librerías externas.

## Cómo ejecutar
Desde la carpeta `pokemon_simulator`, ejecuta:

```bash
python main.py
```

## Funciones
- Capturar Pokémon
- Entrenar y mejorar estadísticas
- Consultar información y poder total
- Contar Pokémon registrados
- Liberar Pokémon
- Simular combates

## Para completar la entrega
Agrega capturas reales de la ejecución y pega el enlace de tu repositorio de GitHub en el PDF solicitado por el profesor.
