"""Paquete con las clases del simulador Pokémon."""
