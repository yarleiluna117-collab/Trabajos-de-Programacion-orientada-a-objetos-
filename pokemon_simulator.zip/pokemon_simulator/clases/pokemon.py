class Pokemon:
    # Variable de clase: cuenta todos los Pokémon creados
    cantidad_pokemons = 0

    def __init__(self, nombre, tipo, ataque, defensa, salud):
        self.nombre = nombre
        self.tipo = tipo
        self.nivel = 1
        self.ataque = ataque
        self.defensa = defensa
        self.salud = salud

        Pokemon.cantidad_pokemons += 1
        self.registrado = True

        print(f"\n¡{self.nombre} ha sido capturado! 🐉")

    def __del__(self):
        if getattr(self, "registrado", False):
            Pokemon.cantidad_pokemons -= 1
            self.registrado = False
            print(f"{self.nombre} ha sido liberado ✨")

    def entrenar(self, *mejoras):
        # Sin argumentos, mejora las tres estadísticas
        if len(mejoras) == 0:
            mejoras = (5, 3, 10)

        if len(mejoras) > 3:
            print("Solo puedes indicar hasta 3 mejoras.")
            return

        if any(valor <= 0 for valor in mejoras):
            print("Las mejoras deben ser mayores que cero.")
            return

        self.nivel += 1

        if len(mejoras) >= 1:
            self.ataque += mejoras[0]
        if len(mejoras) >= 2:
            self.defensa += mejoras[1]
        if len(mejoras) >= 3:
            self.salud += mejoras[2]

        print(f"\n¡{self.nombre} subió al nivel {self.nivel}!")
        print("¡El entrenamiento ha terminado! 💪")

    def mostrar_info(self):
        print("\n----- INFORMACIÓN DEL POKÉMON -----")
        print(f"Nombre: {self.nombre}")
        print(f"Tipo: {self.tipo}")
        print(f"Nivel: {self.nivel}")
        print(f"Ataque: {self.ataque}")
        print(f"Defensa: {self.defensa}")
        print(f"Salud: {self.salud}")
        print(f"Poder total: {self.calcular_poder()}")
        print("-----------------------------------")

    def calcular_poder(self):
        return self.ataque + self.defensa + self.salud + self.nivel * 10

    def atacar(self, objetivo):
        if objetivo.salud <= 0:
            print(f"{objetivo.nombre} ya no puede combatir.")
            return

        dano = max(1, self.ataque - objetivo.defensa)
        objetivo.salud = max(0, objetivo.salud - dano)

        print(f"\n¡{self.nombre} atacó a {objetivo.nombre}!")
        print(f"Daño causado: {dano}")
        print(f"Salud restante de {objetivo.nombre}: {objetivo.salud}")

        if objetivo.salud == 0:
            print(f"¡{objetivo.nombre} ha sido derrotado!")

    @classmethod
    def total_pokemons(cls):
        print(f"\nPokémon registrados: {cls.cantidad_pokemons}")
