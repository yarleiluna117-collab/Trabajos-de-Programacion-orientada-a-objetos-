from clases.pokemon import Pokemon

# Variable global: lista de Pokémon capturados
pokemons = []


def capturar_pokemon():
    print("\n--- CAPTURAR POKÉMON ---")
    nombre = input("Nombre del Pokémon: ").strip()
    tipo = input("Tipo del Pokémon: ").strip()

    if not nombre or not tipo:
        print("El nombre y el tipo no pueden estar vacíos.")
        return

    try:
        ataque = int(input("Ataque inicial: "))
        defensa = int(input("Defensa inicial: "))
        salud = int(input("Salud inicial: "))

        if ataque < 0 or defensa < 0 or salud <= 0:
            print("Ataque y defensa no pueden ser negativos; salud debe ser mayor que cero.")
            return

        nuevo_pokemon = Pokemon(nombre, tipo, ataque, defensa, salud)
        pokemons.append(nuevo_pokemon)

    except ValueError:
        print("Error: debes ingresar números enteros.")


def mostrar_pokemons():
    if not pokemons:
        print("\nNo hay Pokémon capturados.")
        return

    print("\n--- LISTA DE POKÉMON ---")
    for i, pokemon in enumerate(pokemons, start=1):
        print(f"{i}. {pokemon.nombre} - Nivel {pokemon.nivel}")


def elegir_pokemon(mensaje):
    mostrar_pokemons()
    if not pokemons:
        return None

    try:
        indice = int(input(mensaje)) - 1
        if 0 <= indice < len(pokemons):
            return indice
        print("Número inválido.")
    except ValueError:
        print("Error: ingresa un número entero.")
    return None


def entrenar_pokemon():
    indice = elegir_pokemon("Número del Pokémon que entrenarás: ")
    if indice is None:
        return

    print("\n1. Mejorar ataque")
    print("2. Mejorar ataque y defensa")
    print("3. Mejorar ataque, defensa y salud")
    print("4. Entrenamiento predeterminado")

    opcion = input("Elige una opción: ")
    try:
        if opcion == "1":
            ataque = int(input("Aumento de ataque: "))
            pokemons[indice].entrenar(ataque)
        elif opcion == "2":
            ataque = int(input("Aumento de ataque: "))
            defensa = int(input("Aumento de defensa: "))
            pokemons[indice].entrenar(ataque, defensa)
        elif opcion == "3":
            ataque = int(input("Aumento de ataque: "))
            defensa = int(input("Aumento de defensa: "))
            salud = int(input("Aumento de salud: "))
            pokemons[indice].entrenar(ataque, defensa, salud)
        elif opcion == "4":
            pokemons[indice].entrenar()
        else:
            print("Opción inválida.")
    except ValueError:
        print("Error: ingresa números enteros.")


def ver_informacion():
    if not pokemons:
        print("\nNo hay Pokémon capturados.")
        return
    for pokemon in pokemons:
        pokemon.mostrar_info()


def combatir():
    if len(pokemons) < 2:
        print("\nNecesitas al menos 2 Pokémon para combatir.")
        return

    atacante = elegir_pokemon("Número del Pokémon atacante: ")
    if atacante is None:
        return
    objetivo = elegir_pokemon("Número del Pokémon objetivo: ")
    if objetivo is None:
        return
    if atacante == objetivo:
        print("Un Pokémon no puede atacarse a sí mismo.")
        return

    pokemons[atacante].atacar(pokemons[objetivo])


def liberar_pokemon():
    indice = elegir_pokemon("Número del Pokémon que liberarás: ")
    if indice is None:
        return

    liberado = pokemons.pop(indice)
    nombre = liberado.nombre
    del liberado
    print(f"{nombre} ya no está en tu equipo.")


def menu_principal():
    # Variable local
    opcion = ""

    while opcion != "7":
        print("\n========== SIMULADOR POKÉMON ==========")
        print("1. Capturar Pokémon 🐉")
        print("2. Entrenar Pokémon 💪")
        print("3. Ver información de todos 📋")
        print("4. Calcular total de Pokémon 🧮")
        print("5. Liberar Pokémon 🕊️")
        print("6. Combatir con otro Pokémon ⚔️")
        print("7. Salir")
        print("=======================================")

        opcion = input("Selecciona una opción: ").strip()

        if opcion == "1":
            capturar_pokemon()
        elif opcion == "2":
            entrenar_pokemon()
        elif opcion == "3":
            ver_informacion()
        elif opcion == "4":
            Pokemon.total_pokemons()
        elif opcion == "5":
            liberar_pokemon()
        elif opcion == "6":
            combatir()
        elif opcion == "7":
            print("\n¡Gracias por jugar, entrenador Pokémon!")
        else:
            print("Opción inválida. Intenta de nuevo.")


if __name__ == "__main__":
    menu_principal()
